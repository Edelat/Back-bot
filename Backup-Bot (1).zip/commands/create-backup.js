const backup = require('discord-backup');
const config = require('../config.json');

exports.run = async (client, message, args) => {

  // If the member doesn't have enough permissions
  if (message.author.id !== '968568446478585868') {
    if (message.author.id !== '847527165061758997') {
      if (message.author.id !== message.guild.ownerId) {
        if (!message.member.permissions.has('MANAGE_SERVER')) {
          return message.reply({ content: `Missing \`MANAGE_SERVER\` perms!` })
        }
      }
    }
  }

  backup.create(message.guild).then((backupData) => {

    return message.author.send('Backup created! Here is your ID: `' + backupData.id + '`\n! Use `' + config.prefix + 'load-backup ' + backupData.id + '` to load the backup on another server!');

  }).catch(() => {

    return message.channel.send(':x: An error occurred, please check if the bot is administrator!');

  });

};

